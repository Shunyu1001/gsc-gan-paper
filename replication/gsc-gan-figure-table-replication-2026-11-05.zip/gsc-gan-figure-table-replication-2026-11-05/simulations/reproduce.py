#!/usr/bin/env python3
"""Replay the three main simulation tables from saved replication values."""
from __future__ import annotations

import argparse
import csv
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ATT_SEEDS = set(range(2026101701, 2026101721))
QTE_SEEDS = set(range(20260825, 20260855))
ATT_TABLE_1_METHODS = ("DR-FGAN", "ASC", "DID/TWFE", "SDID")
ATT_TABLE_3_METHODS = ("DR-FGAN", "LFM (linear factor prediction)", "GSC", "ASC", "DID/TWFE", "SDID")
QTE_METHODS = ("ETC-GAN", "Changes-in-changes (group level)", "CDF-DiD (group level)")
ATT_HEADER = ("Method", "Bias", "MAE", "SD(error)", "RMSE")
QTE_HEADER = ("Method", "Overall MAE", "Lower MAE", "Central MAE", "Upper MAE", "CRPS", "PIT calibration")
QTE_COLUMNS = (
    "pooled_qte_mae",
    "pooled_qte_lower_mae",
    "pooled_qte_central_mae",
    "pooled_qte_upper_mae",
    "crps",
    "pit_calibration_error",
)


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def check_seed_coverage(rows, expected_seeds):
    seeds = [int(row["seed"]) for row in rows]
    if len(seeds) != len(expected_seeds) or set(seeds) != expected_seeds:
        raise ValueError("Unexpected or duplicate seeds in the frozen inputs")


def summarize_att(rows, scenario, methods, expected_sdid_cap_count):
    selected_rows = [row for row in rows if row["scenario"] == scenario]
    results = [ATT_HEADER]
    for method in methods:
        selected = [row for row in selected_rows if row["method"] == method]
        check_seed_coverage(selected, ATT_SEEDS)
        if method == "SDID":
            cap_count = sum(int(row["sdid_reached_iteration_cap"]) for row in selected)
            if cap_count != expected_sdid_cap_count:
                raise ValueError(f"Unexpected SDID iteration-cap count for {scenario}")
        errors = [float(row["estimate"]) - float(row["true_att"]) for row in selected]
        statistics_to_display = (
            statistics.mean(errors),
            statistics.mean(map(abs, errors)),
            statistics.stdev(errors),
            math.sqrt(statistics.mean(error**2 for error in errors)),
        )
        results.append((method, *(f"{value:.5f}" for value in statistics_to_display)))
    return results


def summarize_qte(rows):
    results = [QTE_HEADER]
    for method in QTE_METHODS:
        selected = [row for row in rows if row["method"] == method]
        check_seed_coverage(selected, QTE_SEEDS)
        columns = QTE_COLUMNS if method == "ETC-GAN" else QTE_COLUMNS[:4]
        means = [statistics.mean(float(row[column]) for row in selected) for column in columns]
        cells = [f"{value:.4f}" for value in means]
        cells.extend(["--"] * (len(QTE_COLUMNS) - len(cells)))
        results.append((method, *cells))
    return results


def verify_and_write(results, output_directory):
    for name, rows in results.items():
        with (ROOT / "reference" / name).open(newline="", encoding="utf-8") as file:
            reference = list(map(tuple, csv.reader(file)))
        if rows != reference:
            raise ValueError(f"{name} differs from the November 5 manuscript")

    output_directory.mkdir(parents=True, exist_ok=True)
    for name, rows in results.items():
        with (output_directory / name).open("w", newline="", encoding="utf-8") as file:
            csv.writer(file, lineterminator="\n").writerows(rows)
        print(f"Verified and wrote {output_directory / name}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("reproduced/simulations"))
    args = parser.parse_args()
    att = read_csv(ROOT / "inputs" / "att_saved_estimates.csv")
    qte = read_csv(ROOT / "inputs" / "qte_saved_metrics.csv")
    results = {
        "table1.csv": summarize_att(att, "stable", ATT_TABLE_1_METHODS, 20),
        "table2.csv": summarize_qte(qte),
        "table3.csv": summarize_att(att, "shift", ATT_TABLE_3_METHODS, 19),
    }
    verify_and_write(results, args.output_dir)


if __name__ == "__main__":
    main()
