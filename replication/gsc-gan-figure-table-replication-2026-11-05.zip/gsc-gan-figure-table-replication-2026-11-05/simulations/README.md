# Main-paper simulation tables

This folder reproduces the displayed numeric cells in Tables 1–3 of the November 5, 2026 manuscript.

Run from the extracted package root with Python 3.9 or later. The script uses only the Python standard library.

```sh
python3 simulations/reproduce.py --output-dir reproduced/simulations
```

| Output | Manuscript display | Frozen inputs |
| --- | --- | --- |
| `table1.csv` | Table 1. ATT accuracy when the covariate distribution is stable | 20 saved no-shift replications, seeds 2026101701–2026101720 |
| `table2.csv` | Table 2. Accuracy of quantile treatment effect estimates | 30 saved benchmark panels, seeds 20260825–20260854 |
| `table3.csv` | Table 3. ATT accuracy when the covariate distribution shifts | 20 saved shift replications, matched to the seeds in Table 1 |

The ATT input gives the saved estimates, true ATT, and SDID iteration-limit flags where applicable. The script computes bias, MAE, sample standard deviation of estimation error, and RMSE from these estimates. It checks the SDID iteration-limit counts reported in the paper (20 of 20 for Table 1, 19 of 20 for Table 3).

The QTE input gives only the per-replication metrics behind the displayed cells. The script averages each metric across panels. CRPS and PIT calibration do not apply to the group-level benchmarks, so those cells appear as dashes.

The script compares its rounded cells with the published display values in `reference/`. The inputs are compact projections of the frozen ATT shared-20 results, the ETC-GAN architecture-point results, and the external QTE benchmark panels. The package does not generate new panels, fit models, recreate unit-level predictions, or regenerate supplementary simulation tables.
