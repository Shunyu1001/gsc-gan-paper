#!/usr/bin/env python3
"""Render the author-supplied Figure 1 schematic; no estimation is run.

Unmodified originals are in manuscript/updates/2026-11-04-figure1-v2.
The integration retains the supplied labels and replaces the static equation
number. The caption and notation key are in method_algorithms.tex.
Use --outdir to override the default manuscript/figs (or Overleaf figs).
"""
import argparse
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
from matplotlib.lines import Line2D
from matplotlib import font_manager

AVAILABLE_FONTS = {entry.name for entry in font_manager.fontManager.ttflist}
SERIF = next(name for name in ("Liberation Serif", "Times New Roman", "STIXGeneral")
             if name in AVAILABLE_FONTS)  # Preserve a Times-like serif, never fall back to sans.
plt.rcParams.update({"font.family": SERIF, "mathtext.fontset": "stix", "pdf.fonttype": 42})
INK, SOFT = "#1a1a1a", "#444444"
POINT_INK = "#444444"               # pointers to Figures 2-3
W_IN = 6.3
HEAD, BODY, POINT = 9.8, 8.6, 8.2


class Page:
    def __init__(self, height):
        self.H = height
        self.fig = plt.figure(figsize=(W_IN, height))
        self.fig.patch.set_facecolor("white")

    def fx(self, x):
        return x / W_IN

    def fy(self, top):
        return 1 - top / self.H

    def text(self, x, top, s, **kw):
        kw.setdefault("va", "top"); kw.setdefault("ha", "center"); kw.setdefault("color", INK)
        return self.fig.text(self.fx(x), self.fy(top), s, **kw)

    def line(self, pts, lw=0.9, color=INK):
        self.fig.add_artist(Line2D([self.fx(x) for x, _ in pts], [self.fy(y) for _, y in pts],
                                   transform=self.fig.transFigure, color=color, lw=lw))

    def arrow(self, x0, y0, x1, y1, lw=0.9, color=INK, rad=0.0):
        self.fig.add_artist(FancyArrowPatch((self.fx(x0), self.fy(y0)), (self.fx(x1), self.fy(y1)),
                                            transform=self.fig.transFigure, arrowstyle="-|>",
                                            connectionstyle=f"arc3,rad={rad}", mutation_scale=8,
                                            lw=lw, color=color, shrinkA=0, shrinkB=0))

    def down(self, x, y0, y1):
        self.arrow(x, y0, x, y1)


def step(pg, x, top, title, body=None, pointer=None):
    """Bold plain-language title, one short line, optional pointer to a later figure."""
    pg.text(x, top, title, fontsize=HEAD, weight="bold")
    end = top + 0.19
    if body:
        pg.text(x, end + 0.02, body, fontsize=BODY, color=SOFT)
        end += 0.2
    if pointer:
        pg.text(x, end + 0.03, pointer, fontsize=POINT, style="italic", color=POINT_INK)
        end += 0.2
    return end


def _w(pg, t):
    return t.get_window_extent(renderer=pg.fig.canvas.get_renderer()).width / pg.fig.dpi


def learn_step(pg, x, top, title, pointer, gap=0.7):
    """Learning step in the main flow: the generator-critic loop is centered on the flow line x,
    so the incoming arrow points at the loop and the outgoing arrow leaves from its center."""
    pg.text(x, top, title, fontsize=HEAD, weight="bold")
    ny = top + 0.42
    tg = pg.text(x, ny, "Generator $G$", fontsize=9.0, weight="bold")
    tc = pg.text(x, ny, "Critic", fontsize=9.0, weight="bold")
    wg, wc = _w(pg, tg), _w(pg, tc)
    g_edge, c_edge = x - gap / 2, x + gap / 2            # arrows meet the flow line at its center
    tg.set_position((pg.fx(g_edge - 0.05 - wg / 2), pg.fy(ny)))
    tc.set_position((pg.fx(c_edge + 0.05 + wc / 2), pg.fy(ny)))
    pg.arrow(g_edge, ny + 0.025, c_edge, ny + 0.025, color=INK, lw=1.0)
    pg.arrow(c_edge, ny + 0.105, g_edge, ny + 0.105, color=INK, lw=1.0)
    pg.text(x, ny - 0.17, "$G$ proposes draws", fontsize=7.6)
    pg.text(x, ny + 0.18, "critic tells where they differ", fontsize=7.6)
    pg.text(x, ny + 0.36, pointer, fontsize=POINT, style="italic", color=POINT_INK)
    return ny + 0.36 + 0.17


def draw(pg):
    xc = W_IN / 2
    # ---------------------------------------------------------- shared factor fit
    pg.text(xc, 0.02, "Method Framework", fontsize=HEAD + 3.0, weight="bold")
    s1 = 0.38
    pg.text(xc, s1, "Step 1. Estimate factors $\\hat\\lambda_i, \\hat f_t$ from controls", fontsize=HEAD, weight="bold")
    eq = pg.text(xc, s1 + 0.25,
                 "$(\\hat\\beta,\\hat\\lambda_i,\\hat f_t)=\\arg\\min\\ \\sum_{i\\in C}\\sum_{t}\\,"
                 "(Y_{it}-X_{it}'\\beta-\\lambda_i'f_t)^2$",
                 fontsize=BODY + 0.4, color=SOFT)
    e1 = s1 + 0.25 + eq.get_window_extent(renderer=pg.fig.canvas.get_renderer()).height / pg.fig.dpi
    pg.down(xc, e1 + 0.06, e1 + 0.2)
    e1 += 0.05
    e2 = step(pg, xc, e1 + 0.19, "Step 2. Weight controls to resemble treated units")

    # ---------------------------------------------------------- fork and headers
    xl, xr = 1.78, 4.52
    yb = e2 + 0.08
    pg.line([(xc, e2 + 0.0), (xc, yb)])
    pg.line([(xl, yb), (xr, yb)])
    pg.down(xl, yb, yb + 0.15)
    pg.down(xr, yb, yb + 0.15)
    yh = yb + 0.19
    pg.text(xl, yh, "Algorithm 1. DR-FGAN (ATT)", fontsize=HEAD + 0.4, weight="bold")
    pg.text(xr, yh, "Algorithm 2. ETC-GAN (QTE)", fontsize=HEAD + 0.4, weight="bold")

    # ---------------------------------------------------------- rows
    ar = 0.24                                          # arrow length between rows
    y_r1 = yh + 0.34
    e_r1 = step(pg, xr, y_r1, "Fit the mean, take residuals", "residual $= Y-\\hat\\mu^{Q}$ in untreated cells")
    y_gan = e_r1 + ar + 0.08
    pg.down(xr, e_r1 + 0.05, y_gan - 0.05)
    pg.down(xl, yh + 0.24, y_gan - 0.05)

    e_l1 = learn_step(pg, xl, y_gan, "Learn $Y(0)$ from controls", "Figure 2(a)")
    e_r2 = learn_step(pg, xr, y_gan, "Learn the residual distribution", "Figure 3(a)")

    y_fill = max(e_l1, e_r2) + ar + 0.08
    pg.down(xl, e_l1 + 0.05, y_fill - 0.05)
    pg.down(xr, e_r2 + 0.05, y_fill - 0.05)
    e_l2 = step(pg, xl, y_fill, "Fill in mean $Y(0)$ for treated", "$\\hat\\mu_{it}$: mean of $G$'s draws", "Figure 2(b)")
    e_r3 = step(pg, xr, y_fill, "Fill in $Y(0)$ draws and pool", "$\\hat\\mu^{Q}$ plus residual draws from $G$", "Figure 3(b)")

    y_cmp = max(e_l2, e_r3) + ar + 0.08
    pg.down(xl, e_l2 + 0.05, y_cmp - 0.05)
    pg.down(xr, e_r3 + 0.05, y_cmp - 0.05)
    e_l3 = step(pg, xl, y_cmp, "Calculate ATT with DR correction", None, "weighted residual correction")
    e_r4 = step(pg, xr, y_cmp, "Calculate QTE", None, "Figure 3(b), right")
    return max(e_l3, e_r4)


def layout_height():
    pg = Page(8.0)
    end = draw(pg)
    plt.close(pg.fig)
    return end + 0.06


def render(outdir):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    pg = Page(layout_height())
    draw(pg)
    paths = [outdir / "fig1_overview.pdf", outdir / "fig1_overview.png"]
    pg.fig.savefig(paths[0], metadata={"CreationDate": None, "ModDate": None})
    pg.fig.savefig(paths[1], dpi=300)
    plt.close(pg.fig)
    receipt = {
        "schematic_only": True,
        "estimation_run": False,
        "font_family": SERIF,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "files": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        "figure_references": {"drfgan": 2, "etcgan": 3},
        "equation_reference": "LaTeX eq:att_dr in method_algorithms.tex",
    }
    (outdir / "fig1_overview_manifest.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return paths


def main():
    root = Path(__file__).resolve().parents[1]
    manuscript = root / "manuscript" if (root / "manuscript").is_dir() else root
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=manuscript / "figs")
    args = parser.parse_args()
    for path in render(args.outdir):
        print(path)


if __name__ == "__main__":
    main()
