"""Render the paper's two panel-based GAN mechanism schematics.

Adapted from Yiqing Xu's 2026-11-03 figure update. These are idealized,
artificial examples, not fitted estimates or recorded optimization paths.
No empirical data, model fitting, or experiment runner is invoked.

Run from any directory:
    python methods/render_gan_panel_schematics.py --outdir reproduced/methods

Writes fig_{drfgan,etcgan}_process.{pdf,png} into the output directory.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from scipy.stats import gaussian_kde, skewnorm

rng = np.random.default_rng(11)
import argparse
from pathlib import Path
OUT = Path(__file__).resolve().parent / "reproduced"
PAL = {"amber": ("#e09a2b", "#a85d00"), "teal": ("#2a9d8f", "#1b5e55"), "gray": ("0.55", "0.25")}
NAME = "gray"
MODE = "fill"
OBS, OBS_D = PAL[NAME]                 # observed (controls / treated)
G, GSC = "#004a8c", "#6f9fd0"          # generator, linear start
INK, RULE = "0.15", "0.6"
plt.rcParams.update({"font.family": "Helvetica", "font.size": 9, "axes.linewidth": 0.7,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "xtick.major.width": 0.7, "ytick.major.width": 0.7,
                     "pdf.fonttype": 42, "ps.fonttype": 42})

T, T0 = 20, 14
t = np.arange(1, T + 1)
KEY = [3, 7, 11, 16, 20]                 # periods where distributions are drawn
W = 1.55                                                # width of a sideways density, in periods


def side(ax, tk, y, d, peak, color, fill_alpha=None, w=W, **kw):
    """Density d(y) drawn on its side at period tk; only where visible."""
    if MODE == "mirror" and color in (OBS, OBS_D):
        w = -abs(w)                                     # observed on the left, G on the right
    if MODE in ("outline", "mirror") and color == G and MODE == "outline":
        fill_alpha = None                               # G as a line only, never a fill
    m = d / peak > 0.015
    x = tk + w * d[m] / peak
    if fill_alpha:
        ax.fill_betweenx(y[m], tk, x, color=color, alpha=fill_alpha, lw=0, zorder=kw.get("zorder", 3) - 1)
    ax.plot(x, y[m], color=color, **kw)
    return y[m][0], y[m][-1]


def stem(ax, tk, lo, hi):
    ax.plot([tk, tk], [lo, hi], color=RULE, lw=0.6, zorder=2)


def time_axis(ax, right=1.9):
    ax.axvline(T0 + 0.5, color=RULE, ls=(0, (4, 3)), lw=0.8, zorder=1)
    ax.set_xlim(0.4, T + right)
    ticks = sorted(set([1, T0] + KEY))                   # ticks sit at the distribution periods
    ax.set_xticks(ticks)
    ax.set_xticklabels([r"$T_0$" if k == T0 else r"$T$" if k == T else str(k) for k in ticks])
    ax.grid(axis="y", color="0.92", lw=0.6)
    ax.set_axisbelow(True)


def units(ax, Y, highlight=(), split=None, jit=0.13):
    """Every unit-period as a dot; a few units also drawn as thin paths to show the time series.
    split: first period (1-based) drawn in the darker treated colour."""
    N, TT = Y.shape
    X = t[None, :] + rng.uniform(-jit, jit, (N, TT))
    post = np.zeros(TT, bool) if split is None else (t >= split)
    for i in range(N):
        ax.scatter(X[i, ~post], Y[i, ~post], s=6, color=OBS, alpha=0.40, lw=0, zorder=1)
        ax.scatter(X[i, post], Y[i, post], s=6, color=OBS_D, alpha=0.55, lw=0, zorder=1)
    for i in highlight:
        ax.plot(X[i], Y[i], color=OBS, alpha=0.75, lw=0.55, zorder=2)
        ax.scatter(X[i], Y[i], s=7, color=OBS, alpha=0.9, lw=0, zorder=2)


def overlap_color(a_obs=0.28, a_g=0.16):
    """Colour a reader sees where G's fill lies on top of the observed fill (white paper)."""
    from matplotlib.colors import to_rgb
    o, b = np.array(to_rgb(OBS)), np.array(to_rgb(G))
    c = (1 - a_obs) * np.ones(3) + a_obs * o
    return tuple((1 - a_g) * c + a_g * b)


def legend_core():
    return [Patch(color=OBS, alpha=0.28, lw=0, label="Observed, untreated"),
            Patch(color=OBS_D, alpha=0.38, lw=0, label=r"Observed, treated after $T_0$")]


def legend_overlap():
    return Patch(facecolor=overlap_color(), edgecolor=G, lw=1.0, label="Observed/generated overlap")


def kde(sample, grid):
    return gaussian_kde(sample, bw_method=0.35)(grid)



def treatment_effect(y0):
    """Illustrative effect based on the outcome rank within one period."""
    y0 = np.asarray(y0)
    if y0.ndim != 1 or y0.size == 0:
        raise ValueError("Each period must be a nonempty one-dimensional array.")
    rank = np.argsort(np.argsort(y0, kind="stable"), kind="stable")
    return 0.4 + 0.55 * (1 - (rank + 0.5) / len(y0))


def pool_potential_outcomes(y0_by_period):
    """Pool paired period-specific outcomes without recomputing pooled ranks."""
    periods = [np.asarray(y0) for y0 in y0_by_period]
    if not periods:
        raise ValueError("At least one post-treatment period is required.")
    paired = [(y0, y0 + treatment_effect(y0)) for y0 in periods]
    return (np.concatenate([pair[0] for pair in paired]),
            np.concatenate([pair[1] for pair in paired]))


def main():
    global rng
    rng = np.random.default_rng(11)
    # ======================================================================= DR-FGAN
    # Y_it(0) = g(lambda_i * f_t) + e_it ; g bends (rises, then flattens and falls)
    f = 0.35 + 2.9 * np.sin((t - 0.5) / T * np.pi * 1.05) ** 2
    g = lambda x: 0.4 + 2.6 * x * np.exp(-0.42 * x)
    lam_c = rng.uniform(0.55, 1.25, 30)                      # controls
    lam_t = rng.uniform(1.15, 1.55, 12)                      # treated: higher exposure
    sd = 0.28


    def panel_draws(lam, n_t=T):
        e = np.zeros((len(lam), n_t))
        e[:, 0] = rng.normal(0, sd, len(lam))
        for k in range(1, n_t):
            e[:, k] = 0.6 * e[:, k - 1] + rng.normal(0, sd * 0.8, len(lam))
        return g(np.outer(lam, f)) + e


    Yc = panel_draws(lam_c)
    Yt0 = panel_draws(lam_t)
    att = np.where(t > T0, 0.85 + 0.06 * (t - T0), 0.0)
    Yt = Yt0 + att

    # Linear starting approximation, projected on the control response.
    # This is not an estimated GSC predictive distribution.
    xc = np.outer(lam_c, f).ravel()
    b1, b0 = np.polyfit(xc, g(np.outer(lam_c, f)).ravel(), 1)
    lin = lambda x: b0 + b1 * x

    # population samples for the sideways densities (by period)
    pop_c = rng.uniform(0.55, 1.25, 4000)
    pop_t = rng.uniform(1.15, 1.55, 4000)
    ys = np.linspace(-1.0, 5.0, 500)

    fig, axes = plt.subplots(2, 1, figsize=(7.0, 7.4), sharex=True, gridspec_kw=dict(hspace=0.56))

    # (a) controls
    ax = axes[0]
    hl = tuple(np.argsort(lam_c)[[5, 25]])                      # a low- and a high-loading unit
    units(ax, Yc)
    ax.plot(t, g(np.outer(pop_c, f)).mean(0), color=G, lw=1.6, zorder=5)
    ax.plot(t, lin(np.outer(pop_c, f)).mean(0), color=GSC, lw=1.3, ls=(0, (4, 2)), zorder=5)
    for tk in KEY:
        k = tk - 1
        eps = rng.normal(0, sd, 4000)
        d_obs = kde(g(pop_c * f[k]) + eps, ys)
        d_gsc = kde(g(pop_c * f[k]) + eps + (lin(pop_c * f[k]).mean() - g(pop_c * f[k]).mean()), ys)
        d_g = kde(g(pop_c * f[k]) + rng.normal(0, sd, 4000), ys)
        pk = max(d_obs.max(), d_gsc.max())
        lo, hi = side(ax, tk, ys, d_obs, pk, OBS, fill_alpha=0.28, lw=0.0, zorder=3)
        side(ax, tk, ys, d_gsc, pk, GSC, lw=1.0, ls=(0, (3, 1.5)), zorder=4)
        side(ax, tk, ys, d_g, pk, G, lw=1.3, zorder=4)
        stem(ax, tk, lo, hi)
        m_lin, m_g = lin(pop_c * f[k]).mean(), g(pop_c * f[k]).mean()
        if abs(m_g - m_lin) > 0.2:
            xa = tk + W * 1.08
            ax.annotate("", xy=(xa, m_g), xytext=(xa, m_lin),
                        arrowprops=dict(arrowstyle="-|>", color=G, lw=1.0, mutation_scale=8))
    ax.set_ylim(-0.1, 3.9)
    ax.set_ylabel(r"$Y(0)$, control units")
    time_axis(ax)
    ax.tick_params(labelbottom=True)
    ax.set_xlabel("Time")
    ax.text(0.01, 1.0, "(a) Training on control units", transform=ax.transAxes, fontsize=9.5,
            fontweight="bold", va="bottom")

    # (b) treated
    ax = axes[1]
    units(ax, Yt, split=T0 + 1)
    mu_g = g(np.outer(pop_t, f)).mean(0)
    mu_obs = mu_g + att
    mu_gsc = lin(np.outer(pop_t, f)).mean(0)
    ax.plot(t, mu_obs, color=OBS_D, lw=1.3, zorder=5)
    ax.plot(t, mu_g, color=G, lw=1.6, zorder=5)
    for tk in KEY:
        k = tk - 1
        y0 = g(pop_t * f[k]) + rng.normal(0, sd, 4000)
        d_obs = kde(y0 + att[k], ys)
        d_g = d_obs if tk <= T0 else kde(g(pop_t * f[k]) + rng.normal(0, sd, 4000), ys)   # before T0: G matches exactly
        pk = max(d_obs.max(), d_g.max())
        col = OBS if tk <= T0 else OBS_D
        lo, hi = side(ax, tk, ys, d_obs, pk, col, fill_alpha=0.28 if tk <= T0 else 0.38, lw=0.0, zorder=3)
        lo2, hi2 = side(ax, tk, ys, d_g, pk, G, fill_alpha=0.16, lw=1.3, zorder=4)
        stem(ax, tk, min(lo, lo2), max(hi, hi2))
        if tk > T0:
            xa = tk + W * 1.12 if MODE == "mirror" else tk - 0.35
            ax.annotate("", xy=(xa, mu_obs[k]), xytext=(xa, mu_g[k]),
                        arrowprops=dict(arrowstyle="-|>", color=INK, lw=0.9, mutation_scale=7))
            ax.text(xa + 0.12 if MODE == "mirror" else xa - 0.12, (mu_obs[k] + mu_g[k]) / 2 + 0.12, r"ATT$_t$",
                    ha="left" if MODE == "mirror" else "right", va="center", fontsize=8.5, bbox=dict(fc="white", ec="none", pad=0.6, alpha=0.85), zorder=6)
    ax.text(T0 - 0.3, 0.0, "Pre-treatment outcomes guide\ncalibration and model selection",
            ha="right", fontsize=8, color=INK)
    ax.set_ylim(-0.4, 4.6)
    ax.set_ylabel("Outcome, treated units")
    ax.set_xlabel("Time")
    time_axis(ax)
    ax.text(0.01, 1.0, "(b) Prediction for treated units", transform=ax.transAxes, fontsize=9.5,
            fontweight="bold", va="bottom")

    GFILL = (*np.array(__import__("matplotlib").colors.to_rgb(G)), 0.16)
    leg_kw = dict(loc="upper center", bbox_to_anchor=(0.5, -0.2), frameon=False, fontsize=8.5,
                  handlelength=2.2, columnspacing=1.3)
    axes[0].legend(handles=[
        Patch(color=OBS, alpha=0.28, lw=0, label="Observed outcomes"),
        Line2D([], [], color=GSC, ls=(0, (4, 2)), lw=1.3, label="Linear starting approximation"),
        Line2D([], [], color=G, lw=1.4, label="G after training")], ncol=3, **leg_kw)
    axes[1].legend(handles=[
        legend_overlap(),
        Patch(color=OBS_D, alpha=0.38, lw=0, label=r"Observed, after $T_0$"),
        Patch(facecolor=GFILL, edgecolor=G, lw=1.0, label=r"Counterfactual $Y(0)$")], ncol=3, **leg_kw)
    fig.subplots_adjust(left=0.09, right=0.985, top=0.965, bottom=0.165)
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"fig_drfgan_process.{ext}", dpi=240,
                    bbox_inches="tight", pad_inches=0.04, metadata={"Creator": "render_gan_panel_schematics.py"})
    plt.close(fig)

    # ======================================================================= ETC-GAN
    # residual shape depends on factor exposure: narrow & symmetric when low, wide & left-skewed when high
    f2 = 0.05 + 0.95 * ((t - 1) / (T - 1)) ** 0.9   # exposure grows over time
    mu_q = 2.0 + 0.9 * np.sin((t - 1) / (T - 1) * np.pi * 1.2)                                          # regression mean path (treated)


    def rpar(e):
        a, s = -9.0 * e ** 1.6, 0.25 + 0.75 * e
        dlt = a / np.sqrt(1 + a ** 2)
        return a, -s * dlt * np.sqrt(2 / np.pi), s                  # mean-zero skew-normal


    def rdraw(e, n):
        a, loc, s = rpar(e)
        return skewnorm.rvs(a, loc, s, size=n, random_state=rng)


    def rpdf(y, e):
        a, loc, s = rpar(e)
        return skewnorm.pdf(y, a, loc, s)


    from scipy.stats import norm as _norm


    def rpanel(n):
        z = np.zeros((n, T))
        z[:, 0] = rng.normal(size=n)
        for k in range(1, T):
            z[:, k] = 0.6 * z[:, k - 1] + 0.8 * rng.normal(size=n)
        u = _norm.cdf(z)
        return np.column_stack([skewnorm.ppf(u[:, k], *rpar(f2[k])) for k in range(T)])


    yr = np.linspace(-4.2, 1.8, 600)
    start = np.mean([rpdf(yr, e) for e in f2], axis=0)             # one pooled shape for all periods
    pk_r = max(rpdf(yr, e).max() for e in f2)

    fig, axes = plt.subplots(2, 1, figsize=(7.0, 7.4), gridspec_kw=dict(hspace=0.56))
    ax = axes[0]
    units(ax, rpanel(18))
    for tk in KEY:
        e = f2[tk - 1]
        lo, hi = side(ax, tk, yr, rpdf(yr, e), pk_r, OBS, fill_alpha=0.28, lw=0.0, zorder=3)
        side(ax, tk, yr, start, pk_r, GSC, lw=1.0, ls=(0, (3, 1.5)), zorder=4)
        side(ax, tk, yr, rpdf(yr, e), pk_r, G, lw=1.3, zorder=4)
        stem(ax, tk, lo, hi)
    ax.axhline(0, color=RULE, lw=0.6, zorder=1)
    ax.text(KEY[0] + 0.15, -1.15, "low factor level:\nnarrow", fontsize=7.5, ha="left", va="top", color=INK)
    ax.text(KEY[4] + 0.15, -1.9, "high factor level:\nwide, long lower tail", fontsize=7.5, ha="left", va="top", color=INK)
    ax.set_ylim(-2.45, 1.3)
    ax.set_ylabel("Residual, untreated units")
    time_axis(ax, right=4.9)
    ax.set_xlabel("Time")
    ax.text(0.01, 1.0, "(a) Training: G reshapes the residual distribution", transform=ax.transAxes,
            fontsize=9.5, fontweight="bold", va="bottom")

    # (b) treated outcomes; sideways at key periods; pooled post-T0 margin at the right
    ax = axes[1]
    yy = np.linspace(-2.5, 5.5, 800)
    eff = treatment_effect  # the same within-period rule in dots, densities, and pooling
    Yq0 = mu_q[None, :] + rpanel(14)
    Yq = Yq0.copy()
    for k in range(T0, T):
        Yq[:, k] = Yq0[:, k] + eff(Yq0[:, k])
    units(ax, Yq, split=T0 + 1)
    ax.plot(t, mu_q, color=G, lw=1.1, ls=(0, (1, 1.2)), zorder=5)
    for tk in KEY:
        e = f2[tk - 1]
        y0 = mu_q[tk - 1] + rdraw(e, 5000)
        d0 = kde(y0, yy)
        if tk <= T0:
            lo, hi = side(ax, tk, yy, d0, d0.max(), OBS, fill_alpha=0.28, w=1.3, lw=0.0, zorder=3)
            side(ax, tk, yy, d0, d0.max(), G, fill_alpha=0.16, w=1.3, lw=1.3, zorder=4)
        else:
            d1 = kde(y0 + eff(y0), yy)
            pk = max(d0.max(), d1.max())
            lo, hi = side(ax, tk, yy, d1, pk, OBS_D, fill_alpha=0.38, w=1.3, lw=0.0, zorder=3)
            lo2, hi2 = side(ax, tk, yy, d0, pk, G, fill_alpha=0.16, w=1.3, lw=1.3, zorder=4)
            lo, hi = min(lo, lo2), max(hi, hi2)
        stem(ax, tk, lo, hi)

    # pooled after T0: quantile functions in a small side panel that shares the outcome axis
    post = np.where(t > T0)[0]
    post_y0_by_period = [mu_q[k] + rdraw(f2[k], 4000) for k in post]
    Y0, Y1 = pool_potential_outcomes(post_y0_by_period)
    RM = 4.9
    ylo, yhi = -1.15, 5.1
    ins = ax.inset_axes([T + 1.65, ylo, RM - 1.8, yhi - ylo], transform=ax.transData)
    tau = np.linspace(0.02, 0.98, 200)
    Q0, Q1 = np.quantile(Y0, tau), np.quantile(Y1, tau)
    ins.plot(tau, Q1, color=OBS_D, lw=1.6, zorder=3)
    ins.plot(tau, Q0, color=G, lw=1.6, zorder=3)
    for q in (0.1, 0.5, 0.9):
        q0, q1 = np.quantile(Y0, q), np.quantile(Y1, q)
        ins.annotate("", xy=(q, q1), xytext=(q, q0),
                     arrowprops=dict(arrowstyle="-|>", color=INK, lw=0.9, mutation_scale=7, shrinkA=0, shrinkB=0))
    q = 0.5
    ins.text(0.5, np.quantile(Y0, 0.62) - 0.5, "arrows:\n" r"QTE($\tau$)", fontsize=7.5, va="top", ha="left", color=INK)
    ins.set_ylim(ylo, yhi)
    ins.set_xlim(0, 1)
    ins.set_yticks([])
    ins.xaxis.tick_top()
    ins.xaxis.set_label_position("top")
    ins.set_xticks([0.1, 0.5, 0.9])
    ins.set_xticklabels(["0.1", "0.5", "0.9"], fontsize=7.5)
    ins.set_xlabel(r"Quantile $\tau$", fontsize=8, labelpad=3)
    ins.grid(axis="y", color="0.92", lw=0.6)
    for sp in ins.spines.values():
        sp.set_visible(True); sp.set_linewidth(0.6); sp.set_color("0.5")
    ax.set_ylim(ylo, yhi)
    ax.set_ylabel("Outcome, treated units")
    ax.set_xlabel("Time")
    time_axis(ax, right=RM)
    ax.text(0.01, 1.0, r"(b) Prediction: draws after $T_0$ are pooled for the QTE", transform=ax.transAxes,
            fontsize=9.5, fontweight="bold", va="bottom")

    GFILL = (*np.array(__import__("matplotlib").colors.to_rgb(G)), 0.16)
    leg_kw = dict(loc="upper center", bbox_to_anchor=(0.5, -0.2), frameon=False, fontsize=8.5,
                  handlelength=2.2, columnspacing=1.3)
    axes[0].legend(handles=[
        Patch(color=OBS, alpha=0.28, lw=0, label="Observed residuals"),
        Line2D([], [], color=GSC, ls=(0, (3, 1.5)), lw=1.0, label="G before training: one shape"),
        Line2D([], [], color=G, lw=1.3, label="G after training")], ncol=3, **leg_kw)
    axes[1].legend(handles=[
        legend_overlap(),
        Patch(color=OBS_D, alpha=0.38, lw=0, label=r"Observed, after $T_0$"),
        Patch(facecolor=GFILL, edgecolor=G, lw=1.0, label=r"Counterfactual $Y(0)$"),
        Line2D([], [], color=G, lw=1.1, ls=(0, (1, 1.2)), label="Regression mean")], ncol=2, **{**leg_kw, "columnspacing": 1.3})
    fig.subplots_adjust(left=0.09, right=0.985, top=0.965, bottom=0.165)
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"fig_etcgan_process.{ext}", dpi=240,
                    bbox_inches="tight", pad_inches=0.04, metadata={"Creator": "render_gan_panel_schematics.py"})
    plt.close(fig)
    print(f"Rendered DR-FGAN and ETC-GAN panel schematics in {OUT}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=OUT)
    OUT = parser.parse_args().outdir
    OUT.mkdir(parents=True, exist_ok=True)
    main()

