# Figure and Table Replication

Companion to the November 5, 2026 version of *Debiased Counterfactual Estimation for Nonlinear Panel Factor Models: A Generative Deep Learning Approach* by Shunyu Hao. The [paper page](https://shunyu1001.github.io/gsc-gan-paper/) hosts the corresponding manuscript and supplementary information.

## What the package reproduces

| Directory | Paper outputs | Inputs |
| --- | --- | --- |
| `methods/` | Main Figures 1–3 | Schematic drawing scripts. The original published graphics are included for comparison. |
| `simulations/` | Main Tables 1–3 | Saved estimates and error metrics from the simulation replications. |
| `geithner/` | Main Figure 4 and Table 4 | Published pooled quantiles, aggregate ATT estimates, and saved aggregate bootstrap results. |
| `london/` | Main Figure 5 and supplementary Tables 19–25 | Saved aggregate plot coordinates and table inputs. |

The empirical and simulation scripts use saved results. The package contains no raw application datasets and does not refit models or rerun the original simulations. The schematic scripts draw illustrative figures without empirical data. Consult each directory for its output and attribution details.

## Run

From the extracted directory, install the plotting dependencies in a Python 3.11–3.13 environment. The simulation script uses only the standard library.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python methods/render_framework_overview.py --outdir reproduced/methods
python methods/render_gan_panel_schematics.py --outdir reproduced/methods
python simulations/reproduce.py --output-dir reproduced/simulations
python geithner/replay.py --output-dir reproduced/geithner
python london/reproduce.py --output reproduced/london
```

The Windows activation command is `.venv\Scripts\activate`. The graphics can differ in font rendering and PDF metadata across systems. The exact archived schematic PDFs are in `methods/reference/`.

## Version check

SHA-256 hashes of the paper files this archive accompanies:

- Main paper: `f5ab292f089d4542a92536ced2df6a5ae9e0c6af0872ab3c84ea13945e3f82cd`
- Supplementary information: `5136b32ad9d46d4b5a8d201dced6161a4a414969d0f67713631b9b51e2af8fd9`
