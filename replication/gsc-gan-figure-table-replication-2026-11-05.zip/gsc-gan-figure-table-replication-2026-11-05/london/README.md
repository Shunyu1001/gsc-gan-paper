# London electricity tariff application

This directory replays Figure 5 and the seven numerical tables in the London supplementary application from the manuscript dated November 5, 2026 (`4d4a2eb`). It uses saved aggregate estimates and diagnostics from the original fits. It does not fit a model, retrieve data, or reproduce the supplementary rank-sensitivity CDF figure.

Run from the package root with Python, NumPy, Matplotlib, and Pillow:

```sh
python london/reproduce.py --check
python london/reproduce.py --output outputs/london
```

The run writes the Figure 5 PDF and PNG and six TeX fragments under `outputs/london/si/`. One fragment contains two tables. The check compares the numerical plot data and artist properties to the original rendering receipt and the table text to the original manuscript display files. The reference environment was Python 3.13.9, NumPy 2.4.2, and Matplotlib 3.10.6. Graphics may rasterize differently on other systems.

## Inputs and scope

- `inputs/figure_5_values.json` holds the 19 plotted points for the observed, counterfactual, and difference curves, from the primary rank-three fit.
- `inputs/table_values.json` holds aggregate estimates and validation diagnostics for the published rank, initialization, and masked-outcome checks.
- `inputs/abbreviation_keys.json` holds the manuscript's table abbreviation keys.
- `reference/` holds the baseline Figure 5, its plotting signature, and the supplementary table text used for checking.

The raw smart-meter records, household identifiers, household-level predictions, original execution archives, and weather inputs are outside this package. Figure 5 and the supplementary reported effects are point estimates. The seed and rank comparisons describe sensitivity, and the masked checks evaluate prediction for a fixed untreated panel.

## Data attribution

The electricity observations used by the original study came from UK Power Networks' [SmartMeter Energy Consumption Data in London Households](https://data.london.gov.uk/dataset/smartmeter-energy-consumption-data-in-london-households-vqm0d), distributed through London Datastore under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The original study deduplicated and screened the readings, selected households and weeks, and aggregated valid half-hour readings to weekly means. The values in this package are analytical outputs. The data provider does not endorse this analysis.

The original study also used Heathrow observations from [NOAA/NCEI Global Surface Summary of the Day](https://www.ncei.noaa.gov/products/land-based-station/global-summary-of-the-day). That source has its own terms. The package does not redistribute weather observations or weather-bearing input arrays.
