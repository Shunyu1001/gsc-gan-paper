#!/usr/bin/env python3
"""Recreate the November 5 manuscript's Geithner Figure 4 and Table 4."""

import argparse
import csv
import json
from pathlib import Path
from statistics import NormalDist

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


STYLE = {
    "font.family": "serif", "font.serif": ["STIXGeneral"],
    "mathtext.fontset": "stix", "text.usetex": False,
    "font.size": 10, "axes.labelsize": 10, "axes.titlesize": 11,
    "xtick.labelsize": 9, "ytick.labelsize": 9, "legend.fontsize": 8.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": .7, "pdf.fonttype": 42, "path.simplify": False,
    "savefig.facecolor": "white", "savefig.transparent": False,
}


def calculate(data):
    tau = np.asarray(data["tau"], dtype=float)
    np.testing.assert_array_equal(tau, np.arange(1, 20) / 20)
    point = data["point"]
    observed = np.asarray(point["observed_return_quantiles"], dtype=float)
    counterfactual = np.asarray(point["counterfactual_return_quantiles"], dtype=float)
    qte = observed - counterfactual
    boot_qte = np.asarray([draw["qte"] for draw in data["bootstrap"]], dtype=float)
    boot_att = np.asarray([draw["mean_daily_att"] for draw in data["bootstrap"]], dtype=float)
    if boot_qte.shape != (199, 19) or boot_att.shape != (199,):
        raise ValueError("Expected all 199 whole-firm bootstrap summaries.")
    if not (np.isfinite(boot_qte).all() and np.isfinite(boot_att).all()):
        raise ValueError("Bootstrap summaries must be finite.")
    lower, upper = np.quantile(boot_qte, [.025, .975], axis=0, method="linear")
    expected = data["published_check"]
    for values, label in [(qte, "qte"), (lower, "qte_lower_95"), (upper, "qte_upper_95")]:
        np.testing.assert_allclose(values, expected[label], rtol=0, atol=1e-12)
    att = point["mean_daily_att"]
    half_width = NormalDist().inv_cdf(.975) * boot_att.std(ddof=1)
    mean = (att, att - half_width, att + half_width)
    rows = [mean, tuple(10 * value for value in mean)]
    for quantile in (.25, .50, .75):
        i = np.flatnonzero(tau == quantile).item()
        rows.append((observed[i], counterfactual[i], qte[i], lower[i], upper[i]))
    rounded = [[f"{value:.3f}" for value in row] for row in rows]
    if rounded != expected["table_4_rounded"]:
        raise ValueError("Recomputed table does not match the published values.")
    return tau * 100, observed, counterfactual, qte, lower, upper, rounded


def render_figure(output_dir, x, observed, counterfactual, qte, lower, upper):
    with plt.rc_context(STYLE):
        fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.35), layout="constrained")
        axes[0].plot(x, observed, color="#222222", lw=1.5, label=r"$\mathrm{Observed:}\ Y(1)$")
        axes[0].plot(x, counterfactual, color="#777777", lw=1.4, ls="--",
                     label=r"$\mathrm{No\ connection:}\ \widehat{Y}(0)$")
        axes[0].set_ylabel("Daily return (%)")
        axes[0].set_title("(a) Return distributions", loc="left")
        axes[0].legend(frameon=False, loc="upper left", handlelength=2, borderaxespad=.2)
        axes[1].fill_between(x, lower, upper, color="#dddddd", linewidth=0,
                             label="95% pointwise interval", zorder=1)
        axes[1].plot(x, qte, color="#111111", lw=1.5, marker="o", ms=2.5,
                     label=r"$\widehat{\mathrm{QTE}}(\tau)$", zorder=3)
        axes[1].set_ylabel("Observed minus counterfactual\nreturn (percentage points)")
        axes[1].set_title("(b) Quantile effects", loc="left")
        handles, labels = axes[1].get_legend_handles_labels()
        axes[1].legend([handles[1], handles[0]], [labels[1], labels[0]],
                       frameon=False, loc="upper left", handlelength=2, borderaxespad=.2)
        for ax in axes:
            ax.axhline(0, color="#888888", lw=.7, zorder=0)
            ax.set_xlim(2, 98)
            ax.set_xticks([10, 25, 50, 75, 90])
            ax.set_xlabel("Return percentile")
            ax.tick_params(direction="out", width=.7, length=3)
    fig.savefig(output_dir / "figure_4_geithner.pdf", metadata={
        "Title": "Geithner: corrected daily-return distributions and marginal QTE",
        "Subject": "Saved original estimates and 199 pointwise percentile bootstrap draws",
        "Creator": "plot_geithner_corrected_20261029.py", "CreationDate": None, "ModDate": None,
    })
    fig.savefig(output_dir / "figure_4_geithner.png", dpi=220,
                metadata={"Software": "plot_geithner_corrected_20261029.py"})
    plt.close(fig)


def write_table(output_dir, rows):
    mean_names = ["Mean daily ATT", "10-day sum"]
    qte_names = ["25th", "50th (median)", "75th"]
    with (output_dir / "table_4_geithner.csv").open("w", newline="", encoding="utf-8") as fp:
        writer = csv.writer(fp)
        writer.writerow(["panel", "estimand", "estimate_pp", "observed_pct", "counterfactual_pct", "lower_95_pp", "upper_95_pp"])
        for name, (point, lower, upper) in zip(mean_names, rows[:2]):
            writer.writerow(["A", name, point, "", "", lower, upper])
        for name, (observed, counterfactual, qte, lower, upper) in zip(qte_names, rows[2:]):
            writer.writerow(["B", name, qte, observed, counterfactual, lower, upper])

    lines = [r"\begin{tabular}{lrrrr}", r"\toprule",
             r"\multicolumn{5}{l}{Panel A. DR-FGAN average effects (percentage points)} \\",
             r"Estimand & Estimate & \multicolumn{3}{r}{95\% interval} \\", r"\midrule"]
    for name, (point, lower, upper) in zip(mean_names, rows[:2]):
        cells = f"{name} & {point} & " + r"\multicolumn{3}{r}{" + f"[{lower}, {upper}]" + "}"
        lines.append(cells + r" \\")
    lines.extend([r"\midrule", r"\multicolumn{5}{l}{Panel B. Plug-in ETC-GAN marginal quantile effects} \\",
                  r"Percentile & Observed (\%) & Counterfactual (\%) & QTE (pp) & 95\% interval \\", r"\midrule"])
    for name, (observed, counterfactual, qte, lower, upper) in zip(qte_names, rows[2:]):
        lines.append(f"{name} & {observed} & {counterfactual} & {qte} & [{lower}, {upper}]" + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (output_dir / "table_4_geithner.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("output"),
                        help="Write the replayed figure and table here (default: ./output).")
    args = parser.parse_args()
    inputs = Path(__file__).with_name("aggregate_results.json")
    data = json.loads(inputs.read_text(encoding="utf-8"))
    *plot_values, rows = calculate(data)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    render_figure(args.output_dir, *plot_values)
    write_table(args.output_dir, rows)
    print("Verified Geithner Figure 4 and Table 4 against the saved manuscript values.")


if __name__ == "__main__":
    main()
