# Geithner application

```sh
python geithner/replay.py --output-dir reproduced/geithner
```

Run from the package root after installing NumPy and Matplotlib. The command writes Figure 4 as PDF and PNG and Table 4 as CSV and a LaTeX `tabular` (`booktabs` required to compile the latter). It verifies all 19 figure quantile values and both pointwise interval endpoints against the frozen plotting record. It also checks that all five table rows round to the published values.

The script recomputes ATT normal intervals using the bootstrap standard deviation of the 199 saved mean daily ATT estimates, and pointwise QTE intervals using the 2.5th and 97.5th linear percentiles of the 199 saved pooled QTE estimates. The 10-day total adds the ten daily effects. The shaded interval is pointwise, not simultaneous.

The inputs are aggregate outputs from the November 5, 2026 paper at source commit `4d4a2eb2e672e4aa78c2b7a7be429d4c15e8d341`. Point estimates and reference intervals come from `publication_artifacts/application_plain_legends_20261104/geithner/plotted_values.json`. The 199 aggregate bootstrap results and baseline ATT come from `publication_artifacts/geithner_corrected_inference_20261029/replicate_results.json`. The shipped input has pooled quantiles and mean treatment effects only. It contains no firm records, firm identifiers, return series, resampling index arrays, model weights, or checkpoints. No model is fitted. This replay requires neither the raw data nor a GPU.

The empirical application uses the replication data of Acemoglu, Johnson, Kermani, Kwak, and Mitton (2016), *The Value of Connections in Turbulent Times: Evidence from the United States*, [doi:10.1016/j.jfineco.2015.10.001](https://doi.org/10.1016/j.jfineco.2015.10.001). Refer to the source for access and terms governing the original data.
